import React from 'react';
import { ShoppingCart, Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import { Link } from '../ui/Link';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Logo and About */}
          <div>
            <div className="flex items-center mb-4">
              <ShoppingCart className="mr-2 text-primary-500" />
              <span className="text-2xl font-bold text-white">ShopNest</span>
            </div>
            <p className="text-gray-400 mb-4">
              Your one-stop destination for quality products at affordable prices.
              We deliver unique shopping experiences with excellent customer service.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Facebook />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Twitter />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary-500 transition-colors">
                <Instagram />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-gray-700 pb-2">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/shop" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  Shop
                </Link>
              </li>
              <li>
                <Link to="/categories" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  Categories
                </Link>
              </li>
              <li>
                <Link to="/cart" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  Cart
                </Link>
              </li>
              <li>
                <Link to="/account" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  My Account
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Customer Service */}
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-gray-700 pb-2">Customer Service</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/contact" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/returns" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  Returns & Exchanges
                </Link>
              </li>
              <li>
                <Link to="/shipping" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  Shipping Policy
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-gray-400 hover:text-primary-500 transition-colors inline-block py-1">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4 border-b border-gray-700 pb-2">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="w-5 h-5 mr-3 text-primary-500 flex-shrink-0 mt-0.5" />
                <span className="text-gray-400">
                  Hyderabad, Telangana, 500076, INDIA
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="w-5 h-5 mr-3 text-primary-500 flex-shrink-0" />
                <span className="text-gray-400">+91 9182977650</span>
              </li>
              <li className="flex items-center">
                <Mail className="w-5 h-5 mr-3 text-primary-500 flex-shrink-0" />
                <span className="text-gray-400">support@shopnest.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Newsletter */}
        <div className="border-t border-gray-800 mt-8 pt-8 mb-8">
          <div className="max-w-xl mx-auto text-center">
            <h3 className="text-lg font-semibold mb-2">Subscribe to our Newsletter</h3>
            <p className="text-gray-400 mb-4">Get updates on new products, special offers, and more.</p>
            <div className="flex flex-col sm:flex-row sm:max-w-md mx-auto">
              <input
                type="email"
                placeholder="Your email address"
                className="input bg-gray-800 border-gray-700 text-white mb-2 sm:mb-0 sm:mr-2 focus:border-primary-500"
              />
              <button className="btn btn-primary">Subscribe</button>
            </div>
          </div>
        </div>
        
        {/* Copyright */}
        <div className="border-t border-gray-800 pt-6 mt-6 text-center text-gray-500 text-sm">
          <p>© {new Date().getFullYear()} ShopNest. All rights reserved.</p>
          <p className="mt-1">
            Designed and built with <span className="text-accent-500">♥</span> for quality shopping.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;