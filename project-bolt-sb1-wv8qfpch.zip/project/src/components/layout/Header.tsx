import React, { useState, useEffect } from 'react';
import { ShoppingCart, User, Heart, Menu, X, Search, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { Link } from '../ui/Link';

const Header: React.FC = () => {
  const { state: authState, logout } = useAuth();
  const { state: cartState } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  
  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Toggle mobile menu
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Toggle user dropdown
  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.user-dropdown')) {
        setDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="text-2xl font-bold text-primary-600 flex items-center">
            <ShoppingCart className="mr-2" />
            <span>ShopNest</span>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-primary-600 transition-colors">Home</Link>
            <Link to="/shop" className="text-gray-700 hover:text-primary-600 transition-colors">Shop</Link>
            <Link to="/categories" className="text-gray-700 hover:text-primary-600 transition-colors">Categories</Link>
            <Link to="/about" className="text-gray-700 hover:text-primary-600 transition-colors">About</Link>
            <Link to="/contact" className="text-gray-700 hover:text-primary-600 transition-colors">Contact</Link>
          </nav>
          
          {/* Search Bar */}
          <div className="hidden md:flex relative">
            <input
              type="text"
              placeholder="Search products..."
              className="input !py-1.5 !pl-9 !pr-4 w-64"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          </div>
          
          {/* User Actions */}
          <div className="flex items-center space-x-4">
            {/* Wishlist */}
            <Link to="/wishlist" className="text-gray-700 hover:text-primary-600 transition-colors relative">
              <Heart className="w-6 h-6" />
            </Link>
            
            {/* Cart */}
            <Link to="/cart" className="text-gray-700 hover:text-primary-600 transition-colors relative">
              <ShoppingCart className="w-6 h-6" />
              {cartState.items.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-fade-in">
                  {cartState.items.length}
                </span>
              )}
            </Link>
            
            {/* User */}
            {authState.isAuthenticated ? (
              <div className="relative user-dropdown">
                <button 
                  className="flex items-center space-x-1 focus:outline-none"
                  onClick={toggleDropdown}
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-primary-500">
                    <img 
                      src={authState.user?.avatar || 'https://images.pexels.com/photos/1933873/pexels-photo-1933873.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'} 
                      alt="User"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </button>
                
                {dropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10 animate-slide-down">
                    <div className="px-4 py-2 border-b border-gray-100">
                      <p className="text-sm font-semibold">{authState.user?.name}</p>
                      <p className="text-xs text-gray-500">{authState.user?.email}</p>
                    </div>
                    <Link to="/account" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      Account Settings
                    </Link>
                    <Link to="/orders" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                      My Orders
                    </Link>
                    <button 
                      onClick={logout}
                      className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-100 flex items-center"
                    >
                      <LogOut className="w-4 h-4 mr-2" />
                      Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link to="/login" className="flex items-center text-gray-700 hover:text-primary-600 transition-colors">
                <User className="w-6 h-6" />
              </Link>
            )}
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-gray-700 hover:text-primary-600 transition-colors"
              onClick={toggleMobileMenu}
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white mt-4 rounded-lg shadow-lg p-4 animate-slide-down">
            <div className="mb-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search products..."
                  className="input !py-2 !pl-9 !pr-4 w-full"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              </div>
            </div>
            <nav className="flex flex-col space-y-3">
              <Link to="/" className="text-gray-700 hover:text-primary-600 transition-colors py-2">Home</Link>
              <Link to="/shop" className="text-gray-700 hover:text-primary-600 transition-colors py-2">Shop</Link>
              <Link to="/categories" className="text-gray-700 hover:text-primary-600 transition-colors py-2">Categories</Link>
              <Link to="/about" className="text-gray-700 hover:text-primary-600 transition-colors py-2">About</Link>
              <Link to="/contact" className="text-gray-700 hover:text-primary-600 transition-colors py-2">Contact</Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;