import React from 'react';
import { Category } from '../../types';
import { Link } from './Link';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link to={`/shop?category=${category.slug}`} className="block group">
      <div className="relative h-80 overflow-hidden rounded-lg shadow-md transition-all duration-300 group-hover:shadow-lg">
        {/* Background Image */}
        <img 
          src={category.image} 
          alt={category.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/60 group-hover:to-black/70 transition-colors duration-300"></div>
        
        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-6 text-white transition-all duration-300 group-hover:pb-8">
          <h3 className="text-2xl font-bold mb-2">{category.name}</h3>
          {category.description && (
            <p className="text-sm text-white/80 mb-4 max-w-xs">{category.description}</p>
          )}
          <span className="inline-block text-white bg-primary-600 hover:bg-primary-700 transition-colors duration-200 px-4 py-2 rounded text-sm font-medium">
            Shop Now
          </span>
        </div>
      </div>
    </Link>
  );
};

export default CategoryCard;