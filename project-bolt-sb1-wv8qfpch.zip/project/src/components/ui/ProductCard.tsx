import React from 'react';
import { Heart, ShoppingCart, Star, Eye } from 'lucide-react';
import { Product } from '../../types';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { Link } from './Link';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  const handleAddToCart = () => {
    addToCart(product, 1);
  };

  const toggleWishlist = () => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  // Calculate discounted price if there is a discount
  const price = product.discount
    ? product.price * (1 - product.discount / 100)
    : product.price;

  return (
    <div className="card card-hover group transition-all duration-300 h-full flex flex-col">
      {/* Image Container */}
      <div className="relative overflow-hidden h-60">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover transform transition-transform duration-300 group-hover:scale-105"
        />
        
        {/* Quick Action Buttons - appear on hover */}
        <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex justify-end space-x-2">
          <button
            onClick={toggleWishlist}
            className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors duration-200 ${
              isInWishlist(product.id)
                ? 'bg-accent-500 text-white'
                : 'bg-white text-gray-800 hover:bg-accent-500 hover:text-white'
            }`}
            aria-label={isInWishlist(product.id) ? "Remove from wishlist" : "Add to wishlist"}
          >
            <Heart className="w-4 h-4" />
          </button>
          
          <Link
            to={`/product/${product.id}`}
            className="w-8 h-8 rounded-full bg-white text-gray-800 flex items-center justify-center transition-colors duration-200 hover:bg-primary-500 hover:text-white"
            aria-label="View details"
          >
            <Eye className="w-4 h-4" />
          </Link>
          
          <button
            onClick={handleAddToCart}
            className="w-8 h-8 rounded-full bg-white text-gray-800 flex items-center justify-center transition-colors duration-200 hover:bg-primary-500 hover:text-white"
            aria-label="Add to cart"
          >
            <ShoppingCart className="w-4 h-4" />
          </button>
        </div>
        
        {/* Badge for discounts or featured status */}
        {product.discount && (
          <div className="absolute top-2 left-2">
            <span className="bg-accent-500 text-white text-xs font-bold px-2 py-1 rounded">
              {product.discount}% OFF
            </span>
          </div>
        )}
        
        {product.featured && !product.discount && (
          <div className="absolute top-2 left-2">
            <span className="bg-primary-500 text-white text-xs font-bold px-2 py-1 rounded">
              Featured
            </span>
          </div>
        )}
      </div>
      
      {/* Product Info */}
      <div className="p-4 flex-grow flex flex-col">
        <div className="flex items-center mb-1">
          <span className="flex items-center text-yellow-400 mr-1">
            <Star className="w-4 h-4 fill-current" />
          </span>
          <span className="text-sm font-medium">{product.rating}</span>
          <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
        </div>
        
        <Link to={`/product/${product.id}`} className="block">
          <h3 className="text-gray-800 font-medium mb-1 hover:text-primary-600 transition-colors duration-200">
            {product.name}
          </h3>
        </Link>
        
        <p className="text-gray-500 text-sm mb-2 line-clamp-2 flex-grow">
          {product.description.substring(0, 100)}...
        </p>
        
        <div className="mt-auto">
          <div className="flex items-center justify-between">
            <div>
              {product.discount ? (
                <div className="flex items-center">
                  <span className="text-gray-800 font-bold">${price.toFixed(2)}</span>
                  <span className="text-gray-500 text-sm line-through ml-2">
                    ${product.price.toFixed(2)}
                  </span>
                </div>
              ) : (
                <span className="text-gray-800 font-bold">${product.price.toFixed(2)}</span>
              )}
            </div>
            
            <button
              onClick={handleAddToCart}
              className="btn btn-primary btn-small whitespace-nowrap"
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;