import React, { useState, useEffect } from 'react';

// Context Providers
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { WishlistProvider } from './context/WishlistContext';

// Pages
import HomePage from './pages/HomePage';
import ShopPage from './pages/ShopPage';
import ProductPage from './pages/ProductPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';

const App: React.FC = () => {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);

  // Handle navigation changes
  useEffect(() => {
    const handleLocationChange = () => {
      setCurrentPath(window.location.pathname);
    };

    // Listen for navigation events
    window.addEventListener('popstate', handleLocationChange);

    return () => {
      window.removeEventListener('popstate', handleLocationChange);
    };
  }, []);

  // Render the appropriate page based on the current path
  const renderPage = () => {
    if (currentPath === '/') {
      return <HomePage />;
    } else if (currentPath === '/shop' || currentPath.startsWith('/shop?')) {
      return <ShopPage />;
    } else if (currentPath.startsWith('/product/')) {
      return <ProductPage />;
    } else if (currentPath === '/cart') {
      return <CartPage />;
    } else if (currentPath === '/checkout') {
      return <CheckoutPage />;
    } else if (currentPath === '/login') {
      return <LoginPage />;
    } else if (currentPath === '/register') {
      return <RegisterPage />;
    } else {
      // Default to home page or could be a 404 page
      return <HomePage />;
    }
  };

  return (
    <AuthProvider>
      <CartProvider>
        <WishlistProvider>
          {renderPage()}
        </WishlistProvider>
      </CartProvider>
    </AuthProvider>
  );
};

export default App;