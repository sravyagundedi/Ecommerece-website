import React, { useState } from 'react';
import { CreditCard, Lock, ChevronRight, CheckCircle, Info } from 'lucide-react';

import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { Link } from '../components/ui/Link';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { ShippingAddress } from '../types';

const CheckoutPage: React.FC = () => {
  const { state: cartState, clearCart } = useCart();
  const { state: authState } = useAuth();
  
  // Checkout steps
  const [currentStep, setCurrentStep] = useState(1);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderId, setOrderId] = useState('');
  
  // Form states
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>({
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'United States',
    phone: '',
  });
  
  const [billingAddress, setBillingAddress] = useState<ShippingAddress>({
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'United States',
    phone: '',
  });
  
  const [sameAsShipping, setSameAsShipping] = useState(true);
  
  const [paymentMethod, setPaymentMethod] = useState('credit-card');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    name: '',
    expiry: '',
    cvc: '',
  });
  
  // Handle form changes
  const handleShippingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setShippingAddress(prev => ({ ...prev, [name]: value }));
  };
  
  const handleBillingChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setBillingAddress(prev => ({ ...prev, [name]: value }));
  };
  
  const handleCardDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCardDetails(prev => ({ ...prev, [name]: value }));
  };
  
  // Toggle same as shipping
  const handleSameAsShippingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSameAsShipping(e.target.checked);
    if (e.target.checked) {
      setBillingAddress(shippingAddress);
    }
  };
  
  // Calculate totals
  const subtotal = cartState.total;
  const shippingCost = subtotal > 100 ? 0 : 10;
  const taxRate = 0.08;
  const taxAmount = subtotal * taxRate;
  const total = subtotal + shippingCost + taxAmount;
  
  // Move to next step
  const nextStep = () => {
    setCurrentStep(prev => prev + 1);
    window.scrollTo(0, 0);
  };
  
  // Move to previous step
  const prevStep = () => {
    setCurrentStep(prev => prev - 1);
    window.scrollTo(0, 0);
  };
  
  // Submit order
  const placeOrder = () => {
    // Simulate order placement
    setTimeout(() => {
      // Generate random order ID
      const newOrderId = `ORD-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`;
      setOrderId(newOrderId);
      setOrderComplete(true);
      clearCart();
      window.scrollTo(0, 0);
    }, 1500);
  };
  
  // If cart is empty and order not complete, redirect to cart
  if (cartState.items.length === 0 && !orderComplete) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl font-bold mb-4">Your cart is empty</h1>
            <p className="text-gray-600 mb-8">
              You need to add some items to your cart before checking out.
            </p>
            <Link to="/shop" className="btn btn-primary">
              Continue Shopping
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  // If not logged in, show login prompt
  if (!authState.isAuthenticated && !orderComplete) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-md mx-auto bg-white rounded-lg shadow-md p-8">
              <h1 className="text-2xl font-bold mb-4">Sign In Required</h1>
              <p className="text-gray-600 mb-6">
                You need to sign in to your account before proceeding to checkout.
              </p>
              <div className="space-y-4">
                <Link to="/login" className="btn btn-primary w-full">
                  Sign In
                </Link>
                <div className="text-center">
                  <span className="text-gray-600">Don't have an account?</span>
                  <Link to="/register" className="text-primary-600 ml-1 hover:text-primary-700">
                    Create an account
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  // Order complete screen
  if (orderComplete) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-8">
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Order Confirmed!</h1>
                <p className="text-gray-600">
                  Your order has been placed and is being processed.
                </p>
              </div>
              
              <div className="border border-gray-200 rounded-md p-6 mb-8">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900">Order #{orderId}</h2>
                    <p className="text-gray-600 text-sm">
                      {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
                    </p>
                  </div>
                  <span className="bg-green-100 text-green-800 text-xs font-semibold px-2.5 py-1 rounded">
                    Processing
                  </span>
                </div>
                
                <div className="border-t border-gray-200 pt-4 mt-4">
                  <h3 className="text-md font-semibold mb-2">Order Summary</h3>
                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Shipping</span>
                      <span>{shippingCost === 0 ? 'Free' : `$${shippingCost.toFixed(2)}`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tax</span>
                      <span>${taxAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-semibold border-t border-gray-200 pt-2 mt-2">
                      <span>Total</span>
                      <span>${total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
                
                <div className="border-t border-gray-200 pt-4 mt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-md font-semibold mb-2">Shipping Address</h3>
                      <p className="text-gray-600">
                        {shippingAddress.firstName} {shippingAddress.lastName}<br />
                        {shippingAddress.address}<br />
                        {shippingAddress.city}, {shippingAddress.state} {shippingAddress.postalCode}<br />
                        {shippingAddress.country}
                      </p>
                    </div>
                    <div>
                      <h3 className="text-md font-semibold mb-2">Payment Method</h3>
                      <p className="text-gray-600 flex items-center">
                        <CreditCard className="w-4 h-4 mr-2 text-gray-400" />
                        Credit Card (ending in {cardDetails.number.slice(-4)})
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="text-center space-y-4">
                <p className="text-gray-600">
                  A confirmation email has been sent to your email address.
                </p>
                <div className="space-x-4">
                  <Link to="/shop" className="btn btn-primary">
                    Continue Shopping
                  </Link>
                  <Link to="/orders" className="btn btn-secondary">
                    View Orders
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-16">
        {/* Page Header */}
        <div className="bg-gray-100 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold text-gray-900">Checkout</h1>
            <div className="flex items-center text-sm mt-2">
              <Link to="/" className="text-gray-600 hover:text-primary-600">Home</Link>
              <span className="mx-2 text-gray-400">/</span>
              <Link to="/cart" className="text-gray-600 hover:text-primary-600">Cart</Link>
              <span className="mx-2 text-gray-400">/</span>
              <span className="text-gray-800">Checkout</span>
            </div>
          </div>
        </div>
        
        {/* Checkout Steps */}
        <div className="bg-white border-b">
          <div className="container mx-auto px-4 py-4">
            <div className="flex justify-between max-w-3xl mx-auto">
              <div className={`flex flex-col items-center ${currentStep >= 1 ? 'text-primary-600' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                  currentStep >= 1 ? 'bg-primary-100 text-primary-600' : 'bg-gray-100'
                }`}>
                  1
                </div>
                <span className="text-xs">Shipping</span>
              </div>
              
              <div className="flex-1 flex items-center">
                <div className={`h-1 w-full ${currentStep >= 2 ? 'bg-primary-500' : 'bg-gray-200'}`}></div>
              </div>
              
              <div className={`flex flex-col items-center ${currentStep >= 2 ? 'text-primary-600' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                  currentStep >= 2 ? 'bg-primary-100 text-primary-600' : 'bg-gray-100'
                }`}>
                  2
                </div>
                <span className="text-xs">Payment</span>
              </div>
              
              <div className="flex-1 flex items-center">
                <div className={`h-1 w-full ${currentStep >= 3 ? 'bg-primary-500' : 'bg-gray-200'}`}></div>
              </div>
              
              <div className={`flex flex-col items-center ${currentStep >= 3 ? 'text-primary-600' : 'text-gray-400'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 ${
                  currentStep >= 3 ? 'bg-primary-100 text-primary-600' : 'bg-gray-100'
                }`}>
                  3
                </div>
                <span className="text-xs">Review</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Checkout Content */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Checkout Forms */}
              <div className="lg:w-2/3">
                {/* Step 1: Shipping */}
                {currentStep === 1 && (
                  <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div className="p-6 border-b border-gray-200">
                      <h2 className="text-xl font-bold text-gray-900">Shipping Information</h2>
                    </div>
                    
                    <div className="p-6">
                      <form className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                              First Name*
                            </label>
                            <input
                              type="text"
                              id="firstName"
                              name="firstName"
                              value={shippingAddress.firstName}
                              onChange={handleShippingChange}
                              className="input"
                              required
                            />
                          </div>
                          
                          <div>
                            <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                              Last Name*
                            </label>
                            <input
                              type="text"
                              id="lastName"
                              name="lastName"
                              value={shippingAddress.lastName}
                              onChange={handleShippingChange}
                              className="input"
                              required
                            />
                          </div>
                        </div>
                        
                        <div>
                          <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-1">
                            Street Address*
                          </label>
                          <input
                            type="text"
                            id="address"
                            name="address"
                            value={shippingAddress.address}
                            onChange={handleShippingChange}
                            className="input"
                            required
                          />
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div>
                            <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
                              City*
                            </label>
                            <input
                              type="text"
                              id="city"
                              name="city"
                              value={shippingAddress.city}
                              onChange={handleShippingChange}
                              className="input"
                              required
                            />
                          </div>
                          
                          <div>
                            <label htmlFor="state" className="block text-sm font-medium text-gray-700 mb-1">
                              State/Province*
                            </label>
                            <input
                              type="text"
                              id="state"
                              name="state"
                              value={shippingAddress.state}
                              onChange={handleShippingChange}
                              className="input"
                              required
                            />
                          </div>
                          
                          <div>
                            <label htmlFor="postalCode" className="block text-sm font-medium text-gray-700 mb-1">
                              Postal Code*
                            </label>
                            <input
                              type="text"
                              id="postalCode"
                              name="postalCode"
                              value={shippingAddress.postalCode}
                              onChange={handleShippingChange}
                              className="input"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <label htmlFor="country" className="block text-sm font-medium text-gray-700 mb-1">
                              Country*
                            </label>
                            <select
                              id="country"
                              name="country"
                              value={shippingAddress.country}
                              onChange={handleShippingChange}
                              className="input"
                              required
                            >
                              <option value="United States">United States</option>
                              <option value="Canada">Canada</option>
                              <option value="United Kingdom">United Kingdom</option>
                              <option value="Australia">Australia</option>
                              <option value="Germany">Germany</option>
                              <option value="France">France</option>
                              <option value="Japan">Japan</option>
                            </select>
                          </div>
                          
                          <div>
                            <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                              Phone Number
                            </label>
                            <input
                              type="tel"
                              id="phone"
                              name="phone"
                              value={shippingAddress.phone}
                              onChange={handleShippingChange}
                              className="input"
                              placeholder="Optional"
                            />
                          </div>
                        </div>
                        
                        <div className="flex justify-end">
                          <button
                            type="button"
                            onClick={nextStep}
                            className="btn btn-primary"
                            disabled={
                              !shippingAddress.firstName ||
                              !shippingAddress.lastName ||
                              !shippingAddress.address ||
                              !shippingAddress.city ||
                              !shippingAddress.state ||
                              !shippingAddress.postalCode
                            }
                          >
                            Continue to Payment
                            <ChevronRight className="ml-2 w-4 h-4" />
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                )}
                
                {/* Step 2: Payment */}
                {currentStep === 2 && (
                  <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div className="p-6 border-b border-gray-200">
                      <h2 className="text-xl font-bold text-gray-900">Payment Method</h2>
                    </div>
                    
                    <div className="p-6">
                      <form className="space-y-6">
                        {/* Payment Methods */}
                        <div>
                          <h3 className="text-lg font-medium text-gray-900 mb-4">Select Payment Method</h3>
                          <div className="space-y-4">
                            <div className="relative border border-gray-300 rounded-md px-3 py-4 flex cursor-pointer hover:border-gray-400">
                              <input
                                type="radio"
                                name="payment-method"
                                id="credit-card"
                                value="credit-card"
                                checked={paymentMethod === 'credit-card'}
                                onChange={() => setPaymentMethod('credit-card')}
                                className="h-4 w-4 text-primary-600 focus:ring-primary-500 mt-1"
                              />
                              <label htmlFor="credit-card" className="ml-3 flex flex-col cursor-pointer">
                                <span className="block text-sm font-medium text-gray-900">Credit / Debit Card</span>
                                <span className="block text-sm text-gray-500">Pay with Visa, Mastercard, or American Express</span>
                                <div className="mt-1 flex space-x-2">
                                  <span className="text-xs bg-blue-100 text-blue-800 font-medium py-0.5 px-1.5 rounded">VISA</span>
                                  <span className="text-xs bg-red-100 text-red-800 font-medium py-0.5 px-1.5 rounded">MASTERCARD</span>
                                  <span className="text-xs bg-indigo-100 text-indigo-800 font-medium py-0.5 px-1.5 rounded">AMEX</span>
                                </div>
                              </label>
                            </div>
                            
                            <div className="relative border border-gray-300 rounded-md px-3 py-4 flex cursor-pointer hover:border-gray-400">
                              <input
                                type="radio"
                                name="payment-method"
                                id="paypal"
                                value="paypal"
                                checked={paymentMethod === 'paypal'}
                                onChange={() => setPaymentMethod('paypal')}
                                className="h-4 w-4 text-primary-600 focus:ring-primary-500 mt-1"
                              />
                              <label htmlFor="paypal" className="ml-3 flex flex-col cursor-pointer">
                                <span className="block text-sm font-medium text-gray-900">PayPal</span>
                                <span className="block text-sm text-gray-500">Pay with your PayPal account</span>
                              </label>
                            </div>
                          </div>
                        </div>
                        
                        {/* Credit Card Details */}
                        {paymentMethod === 'credit-card' && (
                          <div className="border-t border-gray-200 pt-6">
                            <h3 className="text-lg font-medium text-gray-900 mb-4">Card Details</h3>
                            <div className="space-y-4">
                              <div>
                                <label htmlFor="card-number" className="block text-sm font-medium text-gray-700 mb-1">
                                  Card Number*
                                </label>
                                <div className="relative">
                                  <input
                                    type="text"
                                    id="card-number"
                                    name="number"
                                    value={cardDetails.number}
                                    onChange={handleCardDetailsChange}
                                    placeholder="1234 5678 9012 3456"
                                    className="input pl-10"
                                    required
                                  />
                                  <CreditCard className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                                </div>
                              </div>
                              
                              <div>
                                <label htmlFor="card-name" className="block text-sm font-medium text-gray-700 mb-1">
                                  Name on Card*
                                </label>
                                <input
                                  type="text"
                                  id="card-name"
                                  name="name"
                                  value={cardDetails.name}
                                  onChange={handleCardDetailsChange}
                                  placeholder="John Doe"
                                  className="input"
                                  required
                                />
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                  <label htmlFor="card-expiry" className="block text-sm font-medium text-gray-700 mb-1">
                                    Expiration Date*
                                  </label>
                                  <input
                                    type="text"
                                    id="card-expiry"
                                    name="expiry"
                                    value={cardDetails.expiry}
                                    onChange={handleCardDetailsChange}
                                    placeholder="MM/YY"
                                    className="input"
                                    required
                                  />
                                </div>
                                
                                <div>
                                  <label htmlFor="card-cvc" className="block text-sm font-medium text-gray-700 mb-1">
                                    CVC/CVV*
                                  </label>
                                  <input
                                    type="text"
                                    id="card-cvc"
                                    name="cvc"
                                    value={cardDetails.cvc}
                                    onChange={handleCardDetailsChange}
                                    placeholder="123"
                                    className="input"
                                    required
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                        
                        {/* Billing Address */}
                        <div className="border-t border-gray-200 pt-6">
                          <div className="flex items-center justify-between mb-4">
                            <h3 className="text-lg font-medium text-gray-900">Billing Address</h3>
                            <div className="flex items-center">
                              <input
                                type="checkbox"
                                id="same-as-shipping"
                                checked={sameAsShipping}
                                onChange={handleSameAsShippingChange}
                                className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                              />
                              <label htmlFor="same-as-shipping" className="ml-2 text-sm text-gray-700">
                                Same as shipping address
                              </label>
                            </div>
                          </div>
                          
                          {!sameAsShipping && (
                            <div className="space-y-4">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                  <label htmlFor="billing-firstName" className="block text-sm font-medium text-gray-700 mb-1">
                                    First Name*
                                  </label>
                                  <input
                                    type="text"
                                    id="billing-firstName"
                                    name="firstName"
                                    value={billingAddress.firstName}
                                    onChange={handleBillingChange}
                                    className="input"
                                    required
                                  />
                                </div>
                                
                                <div>
                                  <label htmlFor="billing-lastName" className="block text-sm font-medium text-gray-700 mb-1">
                                    Last Name*
                                  </label>
                                  <input
                                    type="text"
                                    id="billing-lastName"
                                    name="lastName"
                                    value={billingAddress.lastName}
                                    onChange={handleBillingChange}
                                    className="input"
                                    required
                                  />
                                </div>
                              </div>
                              
                              <div>
                                <label htmlFor="billing-address" className="block text-sm font-medium text-gray-700 mb-1">
                                  Street Address*
                                </label>
                                <input
                                  type="text"
                                  id="billing-address"
                                  name="address"
                                  value={billingAddress.address}
                                  onChange={handleBillingChange}
                                  className="input"
                                  required
                                />
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div>
                                  <label htmlFor="billing-city" className="block text-sm font-medium text-gray-700 mb-1">
                                    City*
                                  </label>
                                  <input
                                    type="text"
                                    id="billing-city"
                                    name="city"
                                    value={billingAddress.city}
                                    onChange={handleBillingChange}
                                    className="input"
                                    required
                                  />
                                </div>
                                
                                <div>
                                  <label htmlFor="billing-state" className="block text-sm font-medium text-gray-700 mb-1">
                                    State/Province*
                                  </label>
                                  <input
                                    type="text"
                                    id="billing-state"
                                    name="state"
                                    value={billingAddress.state}
                                    onChange={handleBillingChange}
                                    className="input"
                                    required
                                  />
                                </div>
                                
                                <div>
                                  <label htmlFor="billing-postalCode" className="block text-sm font-medium text-gray-700 mb-1">
                                    Postal Code*
                                  </label>
                                  <input
                                    type="text"
                                    id="billing-postalCode"
                                    name="postalCode"
                                    value={billingAddress.postalCode}
                                    onChange={handleBillingChange}
                                    className="input"
                                    required
                                  />
                                </div>
                              </div>
                              
                              <div>
                                <label htmlFor="billing-country" className="block text-sm font-medium text-gray-700 mb-1">
                                  Country*
                                </label>
                                <select
                                  id="billing-country"
                                  name="country"
                                  value={billingAddress.country}
                                  onChange={handleBillingChange}
                                  className="input"
                                  required
                                >
                                  <option value="United States">United States</option>
                                  <option value="Canada">Canada</option>
                                  <option value="United Kingdom">United Kingdom</option>
                                  <option value="Australia">Australia</option>
                                  <option value="Germany">Germany</option>
                                  <option value="France">France</option>
                                  <option value="Japan">Japan</option>
                                </select>
                              </div>
                            </div>
                          )}
                        </div>
                        
                        <div className="flex justify-between">
                          <button
                            type="button"
                            onClick={prevStep}
                            className="btn btn-secondary"
                          >
                            Back to Shipping
                          </button>
                          
                          <button
                            type="button"
                            onClick={nextStep}
                            className="btn btn-primary"
                            disabled={
                              paymentMethod === 'credit-card' && (
                                !cardDetails.number ||
                                !cardDetails.name ||
                                !cardDetails.expiry ||
                                !cardDetails.cvc
                              )
                            }
                          >
                            Review Order
                            <ChevronRight className="ml-2 w-4 h-4" />
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                )}
                
                {/* Step 3: Review */}
                {currentStep === 3 && (
                  <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div className="p-6 border-b border-gray-200">
                      <h2 className="text-xl font-bold text-gray-900">Review Your Order</h2>
                    </div>
                    
                    <div className="p-6">
                      {/* Shipping Information */}
                      <div className="mb-6">
                        <div className="flex justify-between items-start mb-3">
                          <h3 className="text-lg font-medium text-gray-900">Shipping Information</h3>
                          <button
                            onClick={() => setCurrentStep(1)}
                            className="text-sm text-primary-600 hover:text-primary-700"
                          >
                            Edit
                          </button>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-md">
                          <p className="text-gray-800">
                            {shippingAddress.firstName} {shippingAddress.lastName}<br />
                            {shippingAddress.address}<br />
                            {shippingAddress.city}, {shippingAddress.state} {shippingAddress.postalCode}<br />
                            {shippingAddress.country}<br />
                            {shippingAddress.phone && `Phone: ${shippingAddress.phone}`}
                          </p>
                        </div>
                      </div>
                      
                      {/* Payment Method */}
                      <div className="mb-6">
                        <div className="flex justify-between items-start mb-3">
                          <h3 className="text-lg font-medium text-gray-900">Payment Method</h3>
                          <button
                            onClick={() => setCurrentStep(2)}
                            className="text-sm text-primary-600 hover:text-primary-700"
                          >
                            Edit
                          </button>
                        </div>
                        <div className="bg-gray-50 p-4 rounded-md">
                          {paymentMethod === 'credit-card' ? (
                            <div className="flex items-center">
                              <CreditCard className="text-gray-400 mr-2" />
                              <div>
                                <p className="text-gray-800">Credit Card</p>
                                <p className="text-gray-600 text-sm">
                                  {cardDetails.number && `**** **** **** ${cardDetails.number.slice(-4)}`}
                                </p>
                              </div>
                            </div>
                          ) : (
                            <p className="text-gray-800">PayPal</p>
                          )}
                        </div>
                      </div>
                      
                      {/* Order Items */}
                      <div className="mb-6">
                        <h3 className="text-lg font-medium text-gray-900 mb-3">Order Items</h3>
                        <div className="border rounded-md divide-y divide-gray-200">
                          {cartState.items.map(item => (
                            <div key={`${item.productId}-${item.size}-${item.color}`} className="p-4 flex items-center">
                              <div className="w-16 h-16 flex-shrink-0 bg-gray-100 rounded overflow-hidden">
                                <img
                                  src={item.product.images[0]}
                                  alt={item.product.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="ml-4 flex-1">
                                <h4 className="text-sm font-medium text-gray-900">{item.product.name}</h4>
                                <div className="mt-1 flex text-sm text-gray-500">
                                  {item.size && <span className="mr-2">Size: {item.size}</span>}
                                  {item.color && <span>Color: {item.color}</span>}
                                </div>
                                <div className="mt-1 text-sm font-medium text-gray-900">
                                  ${item.product.price.toFixed(2)} x {item.quantity}
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="text-sm font-medium text-gray-900">
                                  ${(item.product.price * item.quantity).toFixed(2)}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Terms and Conditions */}
                      <div className="mb-6">
                        <div className="flex items-start">
                          <div className="flex items-center h-5">
                            <input
                              id="terms"
                              name="terms"
                              type="checkbox"
                              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                            />
                          </div>
                          <div className="ml-3 text-sm">
                            <label htmlFor="terms" className="text-gray-700">
                              I agree to the <a href="#" className="text-primary-600 hover:text-primary-700">terms and conditions</a> and <a href="#" className="text-primary-600 hover:text-primary-700">privacy policy</a>.
                            </label>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex justify-between">
                        <button
                          type="button"
                          onClick={prevStep}
                          className="btn btn-secondary"
                        >
                          Back to Payment
                        </button>
                        
                        <button
                          type="button"
                          onClick={placeOrder}
                          className="btn btn-primary"
                        >
                          Place Order
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Order Summary */}
              <div className="lg:w-1/3">
                <div className="bg-white rounded-lg shadow-sm overflow-hidden sticky top-24">
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-xl font-bold text-gray-900 mb-1">Order Summary</h2>
                    <p className="text-gray-600 text-sm">
                      {cartState.items.length} item{cartState.items.length !== 1 ? 's' : ''}
                    </p>
                  </div>
                  
                  <div className="p-6 space-y-4">
                    {/* Item list - Collapsed */}
                    <div className="text-sm">
                      <div
                        className="flex justify-between items-center cursor-pointer"
                        onClick={() => {}}
                      >
                        <span className="text-gray-700 font-medium">Show order details</span>
                        <ChevronRight className="w-4 h-4 text-gray-500" />
                      </div>
                    </div>
                    
                    {/* Price Details */}
                    <div className="border-t border-gray-200 pt-4">
                      <div className="flex justify-between py-2">
                        <span className="text-gray-600">Subtotal</span>
                        <span className="text-gray-900 font-medium">${subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between py-2">
                        <span className="text-gray-600">Shipping</span>
                        <span className="text-gray-900 font-medium">
                          {shippingCost === 0 ? 'Free' : `$${shippingCost.toFixed(2)}`}
                        </span>
                      </div>
                      <div className="flex justify-between py-2">
                        <span className="text-gray-600">Tax (8%)</span>
                        <span className="text-gray-900 font-medium">${taxAmount.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between py-2 border-t border-gray-200 mt-2 pt-2">
                        <span className="text-lg font-bold text-gray-900">Total</span>
                        <span className="text-lg font-bold text-gray-900">${total.toFixed(2)}</span>
                      </div>
                    </div>
                    
                    {/* Secure Checkout */}
                    <div className="border-t border-gray-200 pt-4 text-center">
                      <div className="flex items-center justify-center text-green-700 mb-2">
                        <Lock className="w-4 h-4 mr-1" />
                        <span className="text-sm">Secure Checkout</span>
                      </div>
                      <p className="text-xs text-gray-500">
                        This is a secure checkout process. Your information is encrypted and protected.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default CheckoutPage;