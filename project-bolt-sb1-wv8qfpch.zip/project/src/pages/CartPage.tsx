import React, { useState } from 'react';
import { Trash2, ShoppingCart, ArrowLeft, Truck, ShieldCheck, AlertCircle } from 'lucide-react';

import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { Link } from '../components/ui/Link';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const CartPage: React.FC = () => {
  const { state: cartState, removeFromCart, updateQuantity, clearCart } = useCart();
  const { state: authState } = useAuth();
  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);
  const [couponError, setCouponError] = useState('');

  // Calculate subtotal
  const subtotal = cartState.total;
  
  // Calculate shipping cost (free over $100)
  const shippingCost = subtotal > 100 ? 0 : 10;
  
  // Calculate tax (mock 8%)
  const taxRate = 0.08;
  const taxAmount = subtotal * taxRate;
  
  // Calculate discount
  const discountAmount = couponApplied ? subtotal * 0.1 : 0;
  
  // Calculate total
  const total = subtotal + shippingCost + taxAmount - discountAmount;
  
  // Apply coupon
  const applyCoupon = () => {
    // Mock coupon validation
    if (couponCode.toUpperCase() === 'DISCOUNT10') {
      setCouponApplied(true);
      setCouponError('');
    } else {
      setCouponApplied(false);
      setCouponError('Invalid coupon code');
    }
  };
  
  // Render empty cart
  if (cartState.items.length === 0) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <div className="mb-6 text-gray-400">
                <ShoppingCart className="w-16 h-16 mx-auto" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Your Cart is Empty</h1>
              <p className="text-gray-600 mb-8">
                Looks like you haven't added anything to your cart yet.
                Browse our products and find something you'll love.
              </p>
              <Link to="/shop" className="btn btn-primary">
                Start Shopping
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-16">
        {/* Page Header */}
        <div className="bg-gray-100 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold text-gray-900">Shopping Cart</h1>
            <div className="flex items-center text-sm mt-2">
              <Link to="/" className="text-gray-600 hover:text-primary-600">Home</Link>
              <span className="mx-2 text-gray-400">/</span>
              <span className="text-gray-800">Cart</span>
            </div>
          </div>
        </div>
        
        {/* Cart Content */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Cart Items */}
              <div className="lg:w-2/3">
                <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
                  <div className="p-6 border-b border-gray-200">
                    <div className="flex justify-between items-center">
                      <h2 className="text-xl font-bold text-gray-900">
                        Cart Items ({cartState.items.length})
                      </h2>
                      <button
                        onClick={clearCart}
                        className="text-sm text-gray-600 hover:text-red-600 flex items-center"
                      >
                        <Trash2 className="w-4 h-4 mr-1" />
                        Clear Cart
                      </button>
                    </div>
                  </div>
                  
                  <div className="divide-y divide-gray-200">
                    {cartState.items.map(item => (
                      <div key={`${item.productId}-${item.size}-${item.color}`} className="p-6 flex flex-col sm:flex-row">
                        {/* Product Image */}
                        <div className="sm:w-24 h-24 flex-shrink-0 bg-gray-100 rounded overflow-hidden mb-4 sm:mb-0">
                          <img
                            src={item.product.images[0]}
                            alt={item.product.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        
                        {/* Product Details */}
                        <div className="sm:ml-6 flex-1">
                          <div className="flex flex-col sm:flex-row sm:justify-between">
                            <div>
                              <h3 className="text-lg font-medium text-gray-900 mb-1">
                                <Link to={`/product/${item.product.id}`} className="hover:text-primary-600">
                                  {item.product.name}
                                </Link>
                              </h3>
                              <div className="text-sm text-gray-600 mb-3">
                                {item.size && <span className="mr-2">Size: {item.size}</span>}
                                {item.color && <span>Color: {item.color}</span>}
                              </div>
                            </div>
                            <div className="text-right mt-2 sm:mt-0">
                              <div className="text-lg font-medium text-gray-900">
                                ${(item.product.price * item.quantity).toFixed(2)}
                              </div>
                              <div className="text-sm text-gray-500">
                                ${item.product.price.toFixed(2)} each
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex justify-between items-center mt-4">
                            <div className="flex items-center">
                              <button
                                onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                className="w-8 h-8 border border-gray-300 rounded-l-md flex items-center justify-center text-gray-600 hover:bg-gray-100"
                              >
                                -
                              </button>
                              <input
                                type="text"
                                value={item.quantity}
                                onChange={e => {
                                  const val = parseInt(e.target.value);
                                  if (!isNaN(val) && val > 0) {
                                    updateQuantity(item.productId, val);
                                  }
                                }}
                                className="w-12 h-8 border-t border-b border-gray-300 text-center"
                              />
                              <button
                                onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                                className="w-8 h-8 border border-gray-300 rounded-r-md flex items-center justify-center text-gray-600 hover:bg-gray-100"
                              >
                                +
                              </button>
                            </div>
                            
                            <button
                              onClick={() => removeFromCart(item.productId)}
                              className="text-sm text-gray-600 hover:text-red-600 flex items-center"
                            >
                              <Trash2 className="w-4 h-4 mr-1" />
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="flex justify-between items-center">
                  <Link to="/shop" className="flex items-center text-primary-600 hover:text-primary-700">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Continue Shopping
                  </Link>
                  
                  <button className="btn btn-primary" onClick={() => window.history.pushState({}, '', '/checkout')}>
                    Proceed to Checkout
                  </button>
                </div>
              </div>
              
              {/* Order Summary */}
              <div className="lg:w-1/3">
                <div className="bg-white rounded-lg shadow-sm overflow-hidden sticky top-24">
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-xl font-bold text-gray-900 mb-1">Order Summary</h2>
                    <p className="text-gray-600 text-sm">
                      Shipping and taxes calculated at checkout
                    </p>
                  </div>
                  
                  <div className="p-6 space-y-4">
                    {/* Coupon Code */}
                    <div>
                      <label htmlFor="coupon" className="block text-sm font-medium text-gray-700 mb-2">
                        Coupon Code (Try "DISCOUNT10")
                      </label>
                      <div className="flex">
                        <input
                          type="text"
                          id="coupon"
                          value={couponCode}
                          onChange={e => setCouponCode(e.target.value)}
                          placeholder="Enter coupon code"
                          className="input rounded-r-none flex-1"
                        />
                        <button
                          onClick={applyCoupon}
                          className="bg-gray-100 text-gray-800 px-4 py-2 border border-l-0 border-gray-300 rounded-r-md hover:bg-gray-200"
                        >
                          Apply
                        </button>
                      </div>
                      {couponError && (
                        <p className="text-red-600 text-sm mt-1 flex items-center">
                          <AlertCircle className="w-4 h-4 mr-1" />
                          {couponError}
                        </p>
                      )}
                      {couponApplied && (
                        <p className="text-green-600 text-sm mt-1 flex items-center">
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Coupon applied successfully!
                        </p>
                      )}
                    </div>
                    
                    {/* Price Details */}
                    <div className="border-t border-gray-200 pt-4">
                      <div className="flex justify-between py-2">
                        <span className="text-gray-600">Subtotal</span>
                        <span className="text-gray-900 font-medium">${subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between py-2">
                        <span className="text-gray-600">Shipping</span>
                        <span className="text-gray-900 font-medium">
                          {shippingCost === 0 ? 'Free' : `$${shippingCost.toFixed(2)}`}
                        </span>
                      </div>
                      <div className="flex justify-between py-2">
                        <span className="text-gray-600">Tax (8%)</span>
                        <span className="text-gray-900 font-medium">${taxAmount.toFixed(2)}</span>
                      </div>
                      {couponApplied && (
                        <div className="flex justify-between py-2 text-green-600">
                          <span>Discount (10%)</span>
                          <span>-${discountAmount.toFixed(2)}</span>
                        </div>
                      )}
                      <div className="flex justify-between py-2 border-t border-gray-200 mt-2 pt-2">
                        <span className="text-lg font-bold text-gray-900">Total</span>
                        <span className="text-lg font-bold text-gray-900">${total.toFixed(2)}</span>
                      </div>
                    </div>
                    
                    {/* Checkout Button */}
                    <button 
                      className="btn btn-primary w-full py-3"
                      onClick={() => window.history.pushState({}, '', '/checkout')}
                    >
                      Proceed to Checkout
                    </button>
                    
                    {/* Payment Icons */}
                    <div className="flex items-center justify-center space-x-2 mt-4">
                      <span className="text-xs text-gray-500">We accept:</span>
                      <span className="text-gray-700 font-medium text-xs">Visa</span>
                      <span className="text-gray-700 font-medium text-xs">Mastercard</span>
                      <span className="text-gray-700 font-medium text-xs">PayPal</span>
                    </div>
                  </div>
                  
                  {/* Shipping & Returns */}
                  <div className="p-6 bg-gray-50 space-y-4">
                    <div className="flex">
                      <Truck className="w-5 h-5 text-gray-700 mr-3 flex-shrink-0" />
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">Free Shipping</h4>
                        <p className="text-xs text-gray-600">
                          For orders over $100 (excludes oversized items)
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex">
                      <ShieldCheck className="w-5 h-5 text-gray-700 mr-3 flex-shrink-0" />
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">Easy Returns</h4>
                        <p className="text-xs text-gray-600">
                          30-day return policy for most items
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default CartPage;