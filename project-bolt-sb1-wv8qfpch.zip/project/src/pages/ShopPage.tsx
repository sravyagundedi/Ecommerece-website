import React, { useState, useEffect } from 'react';
import { Filter, X, ChevronDown, Grid3X3, ListFilter, CheckCircle } from 'lucide-react';

import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import ProductCard from '../components/ui/ProductCard';
import { Link } from '../components/ui/Link';

import { products, categories } from '../data/products';
import { Product } from '../types';

const ShopPage: React.FC = () => {
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1000]);
  const [sortBy, setSortBy] = useState('featured');
  const [filtersVisible, setFiltersVisible] = useState(false);
  
  // Get URL parameters for filtering
  useEffect(() => {
    const url = new URL(window.location.href);
    const queryCategory = url.searchParams.get('category');
    const querySearch = url.searchParams.get('search');
    const querySort = url.searchParams.get('sort');
    
    if (queryCategory) setSelectedCategory(queryCategory);
    if (querySearch) setSearchTerm(querySearch);
    if (querySort) setSortBy(querySort);
    
    // Apply filters
    applyFilters(
      querySearch || '',
      queryCategory || '',
      priceRange,
      querySort || 'featured'
    );
  }, []);
  
  // Apply filters function
  const applyFilters = (
    search: string,
    category: string,
    price: [number, number],
    sort: string
  ) => {
    let filtered = [...products];
    
    // Filter by search term
    if (search) {
      filtered = filtered.filter(product => 
        product.name.toLowerCase().includes(search.toLowerCase()) ||
        product.description.toLowerCase().includes(search.toLowerCase())
      );
    }
    
    // Filter by category
    if (category) {
      filtered = filtered.filter(product => 
        product.category.toLowerCase() === category.toLowerCase()
      );
    }
    
    // Filter by price range
    filtered = filtered.filter(product => 
      product.price >= price[0] && product.price <= price[1]
    );
    
    // Sort products
    switch (sort) {
      case 'price-asc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        // In a real app, you would sort by date
        // This is just a simulation
        filtered.sort((a, b) => parseInt(b.id) - parseInt(a.id));
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'featured':
      default:
        filtered.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
    }
    
    setFilteredProducts(filtered);
  };
  
  // Handle filter changes
  const handleFilterChange = () => {
    applyFilters(searchTerm, selectedCategory, priceRange, sortBy);
    
    // Update URL with filters
    const url = new URL(window.location.href);
    
    if (searchTerm) url.searchParams.set('search', searchTerm);
    else url.searchParams.delete('search');
    
    if (selectedCategory) url.searchParams.set('category', selectedCategory);
    else url.searchParams.delete('category');
    
    if (sortBy !== 'featured') url.searchParams.set('sort', sortBy);
    else url.searchParams.delete('sort');
    
    window.history.pushState({}, '', url.toString());
  };
  
  // Handle search change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };
  
  // Handle category change
  const handleCategoryChange = (categorySlug: string) => {
    setSelectedCategory(categorySlug === selectedCategory ? '' : categorySlug);
  };
  
  // Handle price range change
  const handlePriceMinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    setPriceRange([value, priceRange[1]]);
  };
  
  const handlePriceMaxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    setPriceRange([priceRange[0], value]);
  };
  
  // Handle sort change
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSortBy(e.target.value);
  };
  
  // Toggle filters visibility on mobile
  const toggleFilters = () => {
    setFiltersVisible(!filtersVisible);
  };
  
  // Apply filters on change
  useEffect(() => {
    handleFilterChange();
  }, [searchTerm, selectedCategory, priceRange, sortBy]);
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-16">
        {/* Shop Header */}
        <section className="bg-gray-900 text-white py-12">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl font-bold mb-2">Shop All Products</h1>
            <div className="flex flex-wrap items-center">
              <Link to="/" className="text-white/70 hover:text-white">Home</Link>
              <span className="mx-2 text-white/50">/</span>
              <span className="text-white">Shop</span>
            </div>
          </div>
        </section>
        
        {/* Shop Content */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row gap-8">
              {/* Mobile Filter Toggle */}
              <div className="lg:hidden mb-4">
                <button 
                  className="w-full py-3 px-4 bg-gray-100 rounded flex items-center justify-center text-gray-800 font-medium"
                  onClick={toggleFilters}
                >
                  <Filter className="w-4 h-4 mr-2" />
                  {filtersVisible ? 'Hide Filters' : 'Show Filters'}
                </button>
              </div>
              
              {/* Filters Sidebar */}
              <aside className={`${
                filtersVisible ? 'block' : 'hidden'
              } lg:block lg:w-1/4 xl:w-1/5`}>
                <div className="bg-white p-6 rounded-lg shadow-sm sticky top-20">
                  <div className="flex justify-between items-center mb-4">
                    <h2 className="text-xl font-bold">Filters</h2>
                    <button 
                      onClick={() => {
                        setSearchTerm('');
                        setSelectedCategory('');
                        setPriceRange([0, 1000]);
                        setSortBy('featured');
                      }}
                      className="text-sm text-primary-600 hover:text-primary-700"
                    >
                      Clear All
                    </button>
                  </div>
                  
                  {/* Search */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Search
                    </label>
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={handleSearchChange}
                      placeholder="Search products..."
                      className="input"
                    />
                  </div>
                  
                  {/* Categories */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 mb-2">Categories</h3>
                    <div className="space-y-2">
                      {categories.map(category => (
                        <div key={category.id} className="flex items-center">
                          <button
                            onClick={() => handleCategoryChange(category.slug)}
                            className={`flex items-center w-full py-1 px-2 rounded transition-colors ${
                              selectedCategory === category.slug
                                ? 'bg-primary-50 text-primary-700'
                                : 'text-gray-700 hover:bg-gray-50'
                            }`}
                          >
                            {selectedCategory === category.slug && (
                              <CheckCircle className="w-4 h-4 mr-2 text-primary-500" />
                            )}
                            <span>{category.name}</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Price Range */}
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-700 mb-3">Price Range</h3>
                    <div className="flex items-center space-x-4 mb-3">
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Min</label>
                        <input
                          type="number"
                          min="0"
                          max={priceRange[1]}
                          value={priceRange[0]}
                          onChange={handlePriceMinChange}
                          className="input !py-1.5 !px-2 w-24"
                        />
                      </div>
                      <div className="text-gray-400">-</div>
                      <div>
                        <label className="block text-xs text-gray-500 mb-1">Max</label>
                        <input
                          type="number"
                          min={priceRange[0]}
                          value={priceRange[1]}
                          onChange={handlePriceMaxChange}
                          className="input !py-1.5 !px-2 w-24"
                        />
                      </div>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1000"
                      value={priceRange[1]}
                      onChange={handlePriceMaxChange}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-primary-600"
                    />
                  </div>
                </div>
              </aside>
              
              {/* Product Grid */}
              <div className="lg:w-3/4 xl:w-4/5">
                {/* Sort and Count Bar */}
                <div className="flex flex-wrap justify-between items-center mb-6 gap-4">
                  <div className="text-gray-600">
                    Showing <span className="font-medium">{filteredProducts.length}</span> products
                  </div>
                  
                  <div className="flex items-center">
                    <label htmlFor="sort" className="mr-2 text-gray-600">Sort by:</label>
                    <div className="relative">
                      <select
                        id="sort"
                        value={sortBy}
                        onChange={handleSortChange}
                        className="input !py-2 pr-8 appearance-none bg-white"
                      >
                        <option value="featured">Featured</option>
                        <option value="price-asc">Price: Low to High</option>
                        <option value="price-desc">Price: High to Low</option>
                        <option value="newest">Newest</option>
                        <option value="rating">Top Rated</option>
                      </select>
                      <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none" />
                    </div>
                  </div>
                </div>
                
                {/* Products */}
                {filteredProducts.length > 0 ? (
                  <div className="product-grid">
                    {filteredProducts.map(product => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="mb-4 text-gray-400">
                      <X className="w-12 h-12 mx-auto" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No products found</h3>
                    <p className="text-gray-600 mb-6">
                      Try adjusting your search or filter to find what you're looking for.
                    </p>
                    <button
                      onClick={() => {
                        setSearchTerm('');
                        setSelectedCategory('');
                        setPriceRange([0, 1000]);
                        setSortBy('featured');
                      }}
                      className="btn btn-primary"
                    >
                      Clear All Filters
                    </button>
                  </div>
                )}
                
                {/* Pagination (simplified) */}
                {filteredProducts.length > 0 && (
                  <div className="flex justify-center mt-10">
                    <nav className="flex items-center space-x-2">
                      <button className="px-3 py-2 rounded-md bg-primary-100 text-primary-600 font-medium">
                        1
                      </button>
                      <button className="px-3 py-2 rounded-md text-gray-600 hover:bg-gray-100">
                        2
                      </button>
                      <button className="px-3 py-2 rounded-md text-gray-600 hover:bg-gray-100">
                        3
                      </button>
                      <span className="px-3 py-2 text-gray-500">...</span>
                      <button className="px-3 py-2 rounded-md text-gray-600 hover:bg-gray-100">
                        10
                      </button>
                    </nav>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default ShopPage;