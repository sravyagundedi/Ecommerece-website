import React, { useState, useEffect } from 'react';
import { Star, Truck, ShieldCheck, Heart, Share, Minus, Plus, ShoppingCart, Check, ArrowLeft, ArrowRight } from 'lucide-react';

import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import ProductCard from '../components/ui/ProductCard';
import { Link } from '../components/ui/Link';

import { products } from '../data/products';
import { Product } from '../types';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

const ProductPage: React.FC = () => {
  // Get product ID from URL
  const [productId, setProductId] = useState<string>('1');
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  // Extract product id from URL
  useEffect(() => {
    const path = window.location.pathname;
    const id = path.split('/').pop();
    if (id) {
      setProductId(id);
    }
  }, []);
  
  // Fetch product data
  useEffect(() => {
    setLoading(true);
    
    // Simulate API fetch delay
    const timer = setTimeout(() => {
      const foundProduct = products.find(p => p.id === productId);
      if (foundProduct) {
        setProduct(foundProduct);
        setSelectedImage(foundProduct.images[0]);
        
        // Set default selections if available
        if (foundProduct.sizes && foundProduct.sizes.length > 0) {
          setSelectedSize(foundProduct.sizes[0]);
        }
        
        if (foundProduct.colors && foundProduct.colors.length > 0) {
          setSelectedColor(foundProduct.colors[0]);
        }
        
        // Find related products (same category)
        const related = products
          .filter(p => p.category === foundProduct.category && p.id !== foundProduct.id)
          .slice(0, 4);
        setRelatedProducts(related);
      }
      
      setLoading(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [productId]);
  
  // Handle quantity changes
  const incrementQuantity = () => {
    setQuantity(prev => Math.min(prev + 1, product?.stock || 10));
  };
  
  const decrementQuantity = () => {
    setQuantity(prev => Math.max(prev - 1, 1));
  };
  
  // Add to cart
  const handleAddToCart = () => {
    if (product) {
      addToCart(product, quantity, selectedSize, selectedColor);
    }
  };
  
  // Toggle wishlist
  const toggleWishlist = () => {
    if (!product) return;
    
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  // Calculate price
  const calculatePrice = () => {
    if (!product) return { price: 0, originalPrice: 0, discount: false };
    
    const originalPrice = product.price;
    const price = product.discount
      ? originalPrice * (1 - product.discount / 100)
      : originalPrice;
      
    return {
      price,
      originalPrice,
      discount: !!product.discount
    };
  };
  
  const { price, originalPrice, discount } = calculatePrice();
  
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <div className="loader"></div>
        </main>
        <Footer />
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
            <p className="text-gray-600 mb-8">Sorry, the product you are looking for does not exist.</p>
            <Link to="/shop" className="btn btn-primary">
              Continue Shopping
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-16">
        {/* Breadcrumbs */}
        <div className="bg-gray-100 py-4">
          <div className="container mx-auto px-4">
            <div className="flex items-center text-sm">
              <Link to="/" className="text-gray-600 hover:text-primary-600">Home</Link>
              <span className="mx-2 text-gray-400">/</span>
              <Link to="/shop" className="text-gray-600 hover:text-primary-600">Shop</Link>
              <span className="mx-2 text-gray-400">/</span>
              <Link to={`/shop?category=${product.category.toLowerCase()}`} className="text-gray-600 hover:text-primary-600">{product.category}</Link>
              <span className="mx-2 text-gray-400">/</span>
              <span className="text-gray-800 font-medium">{product.name}</span>
            </div>
          </div>
        </div>
        
        {/* Product Details */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row gap-10">
              {/* Product Images */}
              <div className="lg:w-1/2">
                <div className="mb-4 rounded-lg overflow-hidden bg-gray-100 flex items-center justify-center h-[500px]">
                  <img
                    src={selectedImage}
                    alt={product.name}
                    className="w-full h-full object-contain"
                  />
                </div>
                
                {/* Thumbnail Gallery */}
                {product.images.length > 1 && (
                  <div className="flex space-x-2 overflow-x-auto pb-2">
                    {product.images.map((image, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedImage(image)}
                        className={`w-20 h-20 rounded overflow-hidden flex-shrink-0 border-2 ${
                          selectedImage === image ? 'border-primary-500' : 'border-transparent'
                        }`}
                      >
                        <img
                          src={image}
                          alt={`${product.name} - view ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Product Info */}
              <div className="lg:w-1/2">
                <div className="mb-2 flex items-center text-sm">
                  <span className="text-green-500 font-medium flex items-center">
                    <Check className="w-4 h-4 mr-1" />
                    In Stock
                  </span>
                  <span className="mx-2 text-gray-300">|</span>
                  <span className="text-gray-500">SKU: {product.id.padStart(6, '0')}</span>
                </div>
                
                <h1 className="text-3xl font-bold text-gray-900 mb-4">{product.name}</h1>
                
                <div className="flex items-center mb-4">
                  <div className="flex items-center mr-2">
                    {[1, 2, 3, 4, 5].map(star => (
                      <Star
                        key={star}
                        className={`w-5 h-5 ${
                          star <= Math.round(product.rating)
                            ? 'text-yellow-400 fill-current'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">{product.rating}</span>
                    <span className="mx-1">•</span>
                    <span>{product.reviews} reviews</span>
                  </div>
                </div>
                
                <div className="mb-6">
                  <div className="flex items-center">
                    <span className="text-3xl font-bold text-gray-900">${price.toFixed(2)}</span>
                    {discount && (
                      <span className="ml-3 text-lg text-gray-500 line-through">
                        ${originalPrice.toFixed(2)}
                      </span>
                    )}
                    {discount && (
                      <span className="ml-3 bg-accent-100 text-accent-800 px-2 py-1 rounded text-sm font-medium">
                        Save {product.discount}%
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="prose prose-sm text-gray-700 mb-6">
                  <p>{product.description}</p>
                </div>
                
                {/* Size Selection */}
                {product.sizes && product.sizes.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Size</h3>
                    <div className="flex flex-wrap gap-2">
                      {product.sizes.map(size => (
                        <button
                          key={size}
                          onClick={() => setSelectedSize(size)}
                          className={`px-4 py-2 border rounded-md text-sm font-medium transition-colors ${
                            selectedSize === size
                              ? 'border-primary-600 bg-primary-50 text-primary-700'
                              : 'border-gray-300 text-gray-700 hover:border-gray-400'
                          }`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Color Selection */}
                {product.colors && product.colors.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-medium text-gray-900 mb-3">Color</h3>
                    <div className="flex flex-wrap gap-2">
                      {product.colors.map(color => {
                        // This is just a simple mapping - in a real app, you'd have actual color codes
                        const colorClasses: {[key: string]: string} = {
                          'Black': 'bg-gray-900',
                          'White': 'bg-white border-gray-300 border',
                          'Red': 'bg-red-600',
                          'Blue': 'bg-blue-600',
                          'Green': 'bg-green-600',
                          'Yellow': 'bg-yellow-400',
                          'Purple': 'bg-purple-600',
                          'Gray': 'bg-gray-500',
                          'Navy': 'bg-blue-900',
                          'Brown': 'bg-yellow-800',
                          'Pink': 'bg-pink-400',
                          'Orange': 'bg-orange-500',
                          'Silver': 'bg-gray-300',
                          'Gold': 'bg-yellow-600',
                          'Olive': 'bg-yellow-700',
                        };
                        
                        return (
                          <button
                            key={color}
                            onClick={() => setSelectedColor(color)}
                            className={`w-10 h-10 rounded-full flex items-center justify-center transition-transform ${
                              selectedColor === color ? 'ring-2 ring-offset-2 ring-primary-500 scale-110' : ''
                            }`}
                            title={color}
                          >
                            <span className={`w-8 h-8 rounded-full ${colorClasses[color] || 'bg-gray-200'}`}></span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
                
                {/* Quantity */}
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Quantity</h3>
                  <div className="flex items-center">
                    <button
                      onClick={decrementQuantity}
                      disabled={quantity <= 1}
                      className="w-10 h-10 border border-gray-300 rounded-l-md flex items-center justify-center text-gray-600 hover:bg-gray-100 disabled:opacity-50"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <input
                      type="text"
                      value={quantity}
                      onChange={e => {
                        const val = parseInt(e.target.value);
                        if (!isNaN(val) && val > 0 && val <= (product.stock || 10)) {
                          setQuantity(val);
                        }
                      }}
                      className="w-16 h-10 border-t border-b border-gray-300 text-center"
                    />
                    <button
                      onClick={incrementQuantity}
                      disabled={quantity >= (product.stock || 10)}
                      className="w-10 h-10 border border-gray-300 rounded-r-md flex items-center justify-center text-gray-600 hover:bg-gray-100 disabled:opacity-50"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                
                {/* Actions */}
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <button
                    onClick={handleAddToCart}
                    className="btn btn-primary flex-1 py-3 flex items-center justify-center"
                  >
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Add to Cart
                  </button>
                  
                  <button
                    onClick={toggleWishlist}
                    className={`btn flex items-center justify-center py-3 px-4 ${
                      isInWishlist(product.id)
                        ? 'bg-accent-50 text-accent-600 border-accent-200 hover:bg-accent-100'
                        : 'btn-secondary'
                    }`}
                  >
                    <Heart
                      className={`w-5 h-5 ${isInWishlist(product.id) ? 'fill-current' : ''}`}
                    />
                  </button>
                  
                  <button className="btn btn-secondary flex items-center justify-center py-3 px-4">
                    <Share className="w-5 h-5" />
                  </button>
                </div>
                
                {/* Shipping & Returns */}
                <div className="border-t border-gray-200 pt-6 space-y-4">
                  <div className="flex">
                    <Truck className="w-5 h-5 text-gray-500 mr-3 flex-shrink-0" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Free Shipping</h4>
                      <p className="text-sm text-gray-600">Free standard shipping on orders over $100</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <ShieldCheck className="w-5 h-5 text-gray-500 mr-3 flex-shrink-0" />
                    <div>
                      <h4 className="text-sm font-medium text-gray-900">Returns & Warranty</h4>
                      <p className="text-sm text-gray-600">30-day return policy with our hassle-free return process</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Product Description & Reviews */}
        <section className="py-12 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Product Details</h2>
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="prose max-w-none text-gray-700">
                  <p className="mb-4">
                    {product.description}
                  </p>
                  <p className="mb-4">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                  </p>
                  
                  <h3 className="text-lg font-semibold mb-2">Features:</h3>
                  <ul className="list-disc pl-5 mb-4">
                    <li>High-quality materials for durability</li>
                    <li>Expertly crafted with attention to detail</li>
                    <li>Versatile design for multiple occasions</li>
                    <li>Easy to maintain and clean</li>
                    <li>Modern aesthetic that complements any style</li>
                  </ul>
                  
                  <h3 className="text-lg font-semibold mb-2">Specifications:</h3>
                  <table className="min-w-full divide-y divide-gray-200 mb-4">
                    <tbody className="divide-y divide-gray-200">
                      <tr>
                        <td className="py-2 px-4 text-sm font-medium text-gray-900 bg-gray-50">Material</td>
                        <td className="py-2 px-4 text-sm text-gray-700">Premium quality</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-4 text-sm font-medium text-gray-900 bg-gray-50">Dimensions</td>
                        <td className="py-2 px-4 text-sm text-gray-700">Varies by size selected</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-4 text-sm font-medium text-gray-900 bg-gray-50">Weight</td>
                        <td className="py-2 px-4 text-sm text-gray-700">Lightweight</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-4 text-sm font-medium text-gray-900 bg-gray-50">Care Instructions</td>
                        <td className="py-2 px-4 text-sm text-gray-700">See product label for detailed care instructions</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            
            {/* Customer Reviews */}
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Customer Reviews</h2>
                <button className="btn btn-primary">Write a Review</button>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                {/* Review Summary */}
                <div className="p-6 border-b border-gray-200">
                  <div className="flex flex-col md:flex-row md:items-center">
                    <div className="md:w-1/3 mb-6 md:mb-0">
                      <div className="text-center">
                        <div className="text-5xl font-bold text-gray-900 mb-2">{product.rating}</div>
                        <div className="flex items-center justify-center mb-2">
                          {[1, 2, 3, 4, 5].map(star => (
                            <Star
                              key={star}
                              className={`w-5 h-5 ${
                                star <= Math.round(product.rating)
                                  ? 'text-yellow-400 fill-current'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <div className="text-sm text-gray-600">Based on {product.reviews} reviews</div>
                      </div>
                    </div>
                    
                    <div className="md:w-2/3 md:pl-8">
                      <div className="space-y-2">
                        {[5, 4, 3, 2, 1].map(rating => {
                          // Calculate percentage (mock data)
                          const percentage = rating === 5 ? 65 : 
                                            rating === 4 ? 20 :
                                            rating === 3 ? 10 :
                                            rating === 2 ? 3 : 2;
                          
                          return (
                            <div key={rating} className="flex items-center">
                              <div className="flex items-center w-20">
                                <span className="text-sm font-medium text-gray-700 mr-2">{rating}</span>
                                <Star className="w-4 h-4 text-yellow-400 fill-current" />
                              </div>
                              <div className="w-full h-2 bg-gray-200 rounded-full mr-2">
                                <div
                                  className="h-2 bg-yellow-400 rounded-full"
                                  style={{ width: `${percentage}%` }}
                                ></div>
                              </div>
                              <div className="w-12 text-sm text-gray-600">{percentage}%</div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Individual Reviews */}
                <div className="divide-y divide-gray-200">
                  {/* Review 1 */}
                  <div className="p-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mr-4">
                        <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 font-medium">
                          JD
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-lg font-medium text-gray-900">John Doe</h4>
                          <span className="text-sm text-gray-500">2 weeks ago</span>
                        </div>
                        <div className="flex items-center mb-3">
                          {[1, 2, 3, 4, 5].map(star => (
                            <Star
                              key={star}
                              className={`w-4 h-4 ${
                                star <= 5
                                  ? 'text-yellow-400 fill-current'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <h5 className="font-medium text-gray-900 mb-2">Excellent quality and fast delivery!</h5>
                        <p className="text-gray-700 mb-3">
                          I'm extremely happy with this purchase. The quality is outstanding and it arrived faster than expected. Would definitely recommend to anyone looking for this type of product.
                        </p>
                        <div className="flex items-center text-sm text-gray-500">
                          <button className="flex items-center hover:text-gray-700">
                            <span>Helpful</span>
                            <span className="mx-2">•</span>
                          </button>
                          <button className="hover:text-gray-700">Report</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Review 2 */}
                  <div className="p-6">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 mr-4">
                        <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-700 font-medium">
                          JS
                        </div>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-lg font-medium text-gray-900">Jane Smith</h4>
                          <span className="text-sm text-gray-500">1 month ago</span>
                        </div>
                        <div className="flex items-center mb-3">
                          {[1, 2, 3, 4, 5].map(star => (
                            <Star
                              key={star}
                              className={`w-4 h-4 ${
                                star <= 4
                                  ? 'text-yellow-400 fill-current'
                                  : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                        <h5 className="font-medium text-gray-900 mb-2">Great product with minor issues</h5>
                        <p className="text-gray-700 mb-3">
                          Overall, I'm satisfied with this product. It works as described and looks good. The only minor issue is that the color is slightly different from what is shown in the pictures. Otherwise, great purchase!
                        </p>
                        <div className="flex items-center text-sm text-gray-500">
                          <button className="flex items-center hover:text-gray-700">
                            <span>Helpful</span>
                            <span className="mx-2">•</span>
                          </button>
                          <button className="hover:text-gray-700">Report</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* View More Button */}
                <div className="p-6 border-t border-gray-200 text-center">
                  <button className="btn btn-secondary">
                    View All {product.reviews} Reviews
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Related Products */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900">Related Products</h2>
              <div className="flex space-x-2">
                <button className="w-10 h-10 rounded-full bg-white border border-gray-300 flex items-center justify-center text-gray-700 hover:bg-gray-100">
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <button className="w-10 h-10 rounded-full bg-white border border-gray-300 flex items-center justify-center text-gray-700 hover:bg-gray-100">
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="product-grid">
              {relatedProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default ProductPage;