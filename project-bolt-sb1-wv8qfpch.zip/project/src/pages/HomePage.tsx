import React, { useState, useEffect } from 'react';
import { ArrowRight, TrendingUp, ShieldCheck, Truck, CreditCard } from 'lucide-react';

import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import ProductCard from '../components/ui/ProductCard';
import CategoryCard from '../components/ui/CategoryCard';
import { Link } from '../components/ui/Link';

import { products, categories } from '../data/products';

const HomePage: React.FC = () => {
  const [featuredProducts, setFeaturedProducts] = useState(products.filter(p => p.featured));
  const [featuredCategories, setFeaturedCategories] = useState(categories.filter(c => c.featured));

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow pt-16">
        {/* Hero Section */}
        <section className="relative h-[80vh] min-h-[600px] bg-gray-900 flex items-center">
          <div className="absolute inset-0 z-0">
            <img 
              src="https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Hero Background" 
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-black/40"></div>
          </div>
          
          <div className="container mx-auto px-4 z-10">
            <div className="max-w-2xl">
              <h1 className="text-5xl font-bold text-white mb-4 leading-tight animate-fade-in">
                Find Your Style, Elevate Your Life
              </h1>
              <p className="text-xl text-white/80 mb-8 animate-fade-in" style={{ animationDelay: '0.2s' }}>
                Discover a curated collection of premium products that blend style, quality, and innovation.
              </p>
              <div className="flex flex-wrap gap-4 animate-fade-in" style={{ animationDelay: '0.4s' }}>
                <Link to="/shop" className="btn btn-primary btn-large">
                  Shop Now
                </Link>
                <Link to="/categories" className="btn btn-secondary btn-large">
                  View Categories
                </Link>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features Section */}
        <section className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="flex items-center p-6 bg-gray-50 rounded-lg shadow-sm transition-transform duration-300 hover:-translate-y-1">
                <Truck className="w-10 h-10 text-primary-600 mr-4" />
                <div>
                  <h3 className="font-semibold text-lg mb-1">Free Shipping</h3>
                  <p className="text-gray-600 text-sm">On all orders over $100</p>
                </div>
              </div>
              
              <div className="flex items-center p-6 bg-gray-50 rounded-lg shadow-sm transition-transform duration-300 hover:-translate-y-1">
                <ShieldCheck className="w-10 h-10 text-primary-600 mr-4" />
                <div>
                  <h3 className="font-semibold text-lg mb-1">Secure Payments</h3>
                  <p className="text-gray-600 text-sm">100% secure checkout</p>
                </div>
              </div>
              
              <div className="flex items-center p-6 bg-gray-50 rounded-lg shadow-sm transition-transform duration-300 hover:-translate-y-1">
                <CreditCard className="w-10 h-10 text-primary-600 mr-4" />
                <div>
                  <h3 className="font-semibold text-lg mb-1">Easy Returns</h3>
                  <p className="text-gray-600 text-sm">30-day return policy</p>
                </div>
              </div>
              
              <div className="flex items-center p-6 bg-gray-50 rounded-lg shadow-sm transition-transform duration-300 hover:-translate-y-1">
                <TrendingUp className="w-10 h-10 text-primary-600 mr-4" />
                <div>
                  <h3 className="font-semibold text-lg mb-1">Quality Products</h3>
                  <p className="text-gray-600 text-sm">Handpicked premium items</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Featured Categories */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-bold text-gray-800">Shop by Category</h2>
              <Link to="/categories" className="flex items-center text-primary-600 font-medium hover:text-primary-700 transition-colors">
                <span>View All</span>
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredCategories.map(category => (
                <CategoryCard key={category.id} category={category} />
              ))}
            </div>
          </div>
        </section>
        
        {/* Featured Products */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-bold text-gray-800">Featured Products</h2>
              <Link to="/shop" className="flex items-center text-primary-600 font-medium hover:text-primary-700 transition-colors">
                <span>View All</span>
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </div>
            
            <div className="product-grid">
              {featuredProducts.slice(0, 4).map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
        
        {/* Promotional Banner */}
        <section className="py-16 bg-primary-600 relative overflow-hidden">
          <div className="absolute inset-0 opacity-20">
            <img 
              src="https://images.pexels.com/photos/5709639/pexels-photo-5709639.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
              alt="Promotional background" 
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center text-white">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Summer Sale Now Live</h2>
              <p className="text-xl md:text-2xl mb-8">Get up to 50% off on selected items. Limited time offer.</p>
              <Link to="/shop" className="btn btn-large bg-white text-primary-600 hover:bg-gray-100 transition-colors">
                Shop the Sale
              </Link>
            </div>
          </div>
        </section>
        
        {/* New Arrivals */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-10">
              <h2 className="text-3xl font-bold text-gray-800">New Arrivals</h2>
              <Link to="/shop?sort=newest" className="flex items-center text-primary-600 font-medium hover:text-primary-700 transition-colors">
                <span>View All</span>
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </div>
            
            <div className="product-grid">
              {products.slice(4, 8).map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>
        
        {/* Newsletter */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-3xl font-bold text-gray-800 mb-4">Join Our Newsletter</h2>
              <p className="text-gray-600 mb-8">
                Subscribe to our newsletter and get 10% off your first purchase plus updates on new arrivals and exclusive offers.
              </p>
              <div className="flex flex-col sm:flex-row max-w-md mx-auto">
                <input 
                  type="email"
                  placeholder="Your email address"
                  className="input mb-2 sm:mb-0 sm:mr-2 focus:border-primary-500"
                />
                <button className="btn btn-primary">Subscribe</button>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default HomePage;