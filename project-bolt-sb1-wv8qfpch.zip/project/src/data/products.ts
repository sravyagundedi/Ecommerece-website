import { Product, Category } from '../types';

export const categories: Category[] = [
  {
    id: '1',
    name: 'Electronics',
    slug: 'electronics',
    image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Latest gadgets and electronic devices',
    featured: true
  },
  {
    id: '2',
    name: 'Clothing',
    slug: 'clothing',
    image: 'https://images.pexels.com/photos/934070/pexels-photo-934070.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Fashion and apparel for all',
    featured: true
  },
  {
    id: '3',
    name: 'Home & Kitchen',
    slug: 'home-kitchen',
    image: 'https://images.pexels.com/photos/1454806/pexels-photo-1454806.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Everything for your home',
    featured: true
  },
  {
    id: '4',
    name: 'Books',
    slug: 'books',
    image: 'https://images.pexels.com/photos/590493/pexels-photo-590493.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Discover your next read',
    featured: false
  },
  {
    id: '5',
    name: 'Sports',
    slug: 'sports',
    image: 'https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Equipment for all sports',
    featured: false
  },
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Noise-Cancelling Headphones',
    description: 'Premium wireless headphones with active noise cancellation, 30-hour battery life, and high-resolution audio for an immersive listening experience.',
    price: 299.99,
    images: [
      'https://images.pexels.com/photos/577769/pexels-photo-577769.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/8000018/pexels-photo-8000018.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Electronics',
    stock: 15,
    rating: 4.8,
    reviews: 124,
    featured: true,
    tags: ['wireless', 'audio', 'noise-cancelling']
  },
  {
    id: '2',
    name: 'Ultra HD Smart TV - 55"',
    description: 'Crystal clear 4K Ultra HD resolution with smart features, built-in voice assistants, and a sleek design that will transform your living room.',
    price: 699.99,
    images: [
      'https://images.pexels.com/photos/5490778/pexels-photo-5490778.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/5490776/pexels-photo-5490776.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Electronics',
    stock: 8,
    rating: 4.5,
    reviews: 86,
    featured: true,
    tags: ['tv', '4k', 'smart home']
  },
  {
    id: '3',
    name: 'Premium Cotton T-Shirt',
    description: 'Soft, breathable 100% organic cotton t-shirt with a classic fit. Available in multiple colors and sizes.',
    price: 24.99,
    images: [
      'https://images.pexels.com/photos/1656684/pexels-photo-1656684.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/4101142/pexels-photo-4101142.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Clothing',
    stock: 50,
    rating: 4.3,
    reviews: 210,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['White', 'Black', 'Navy', 'Gray', 'Red'],
    tags: ['t-shirt', 'cotton', 'basics']
  },
  {
    id: '4',
    name: 'Slim Fit Jeans',
    description: 'Classic slim fit jeans made from premium denim that offers both style and comfort for everyday wear.',
    price: 59.99,
    images: [
      'https://images.pexels.com/photos/52518/jeans-pants-blue-shop-52518.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/4210866/pexels-photo-4210866.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Clothing',
    stock: 35,
    rating: 4.2,
    reviews: 178,
    sizes: ['28', '30', '32', '34', '36', '38'],
    colors: ['Blue', 'Black', 'Gray'],
    tags: ['jeans', 'denim', 'slim fit']
  },
  {
    id: '5',
    name: 'Professional Blender',
    description: 'High-performance blender with multiple speed settings and pre-programmed cycles for smoothies, soups, and more.',
    price: 149.99,
    images: [
      'https://images.pexels.com/photos/3847342/pexels-photo-3847342.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3802603/pexels-photo-3802603.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Home & Kitchen',
    stock: 12,
    rating: 4.7,
    reviews: 93,
    featured: true,
    tags: ['kitchen', 'appliances', 'blender']
  },
  {
    id: '6',
    name: 'Ergonomic Office Chair',
    description: 'Adjustable office chair with lumbar support, breathable mesh back, and smooth-rolling casters for all-day comfort.',
    price: 199.99,
    images: [
      'https://images.pexels.com/photos/1957478/pexels-photo-1957478.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1957477/pexels-photo-1957477.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Home & Kitchen',
    stock: 7,
    rating: 4.6,
    reviews: 68,
    tags: ['furniture', 'office', 'chair']
  },
  {
    id: '7',
    name: 'Bestselling Fiction Novel',
    description: 'The latest award-winning novel that has captivated readers worldwide with its compelling storytelling and unforgettable characters.',
    price: 18.99,
    images: [
      'https://images.pexels.com/photos/3747163/pexels-photo-3747163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/2908773/pexels-photo-2908773.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Books',
    stock: 25,
    rating: 4.9,
    reviews: 156,
    featured: true,
    tags: ['fiction', 'bestseller', 'reading']
  },
  {
    id: '8',
    name: 'Yoga Mat with Carrying Strap',
    description: 'Thick, non-slip yoga mat with alignment markings and a convenient carrying strap for yogis of all levels.',
    price: 34.99,
    images: [
      'https://images.pexels.com/photos/4056535/pexels-photo-4056535.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/6111616/pexels-photo-6111616.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Sports',
    stock: 20,
    rating: 4.4,
    reviews: 82,
    colors: ['Purple', 'Blue', 'Black', 'Green'],
    tags: ['yoga', 'fitness', 'exercise']
  },
  {
    id: '9',
    name: 'Smartphone with Dual Camera',
    description: 'Latest smartphone model featuring a dual camera system, all-day battery life, and a stunning edge-to-edge display.',
    price: 799.99,
    images: [
      'https://images.pexels.com/photos/887751/pexels-photo-887751.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Electronics',
    stock: 10,
    rating: 4.7,
    reviews: 203,
    colors: ['Black', 'Silver', 'Gold'],
    featured: true,
    tags: ['smartphone', 'mobile', 'camera']
  },
  {
    id: '10',
    name: 'Winter Parka Jacket',
    description: 'Insulated winter parka with water-resistant exterior, faux fur hood, and multiple pockets for ultimate warmth and functionality.',
    price: 149.99,
    images: [
      'https://images.pexels.com/photos/8487465/pexels-photo-8487465.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/6770028/pexels-photo-6770028.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Clothing',
    stock: 15,
    rating: 4.5,
    reviews: 98,
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Black', 'Navy', 'Olive'],
    tags: ['jacket', 'winter', 'outerwear']
  },
  {
    id: '11',
    name: 'Cast Iron Dutch Oven',
    description: 'Versatile enameled cast iron dutch oven perfect for slow cooking, baking, and serving. Retains heat excellently for consistent results.',
    price: 89.99,
    images: [
      'https://images.pexels.com/photos/5824514/pexels-photo-5824514.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/6248840/pexels-photo-6248840.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Home & Kitchen',
    stock: 8,
    rating: 4.8,
    reviews: 74,
    colors: ['Red', 'Blue', 'Black'],
    tags: ['cookware', 'kitchen', 'cast iron']
  },
  {
    id: '12',
    name: 'Cookbook Collection Box Set',
    description: 'A collection of bestselling cookbooks covering everything from quick weeknight meals to elaborate dinner party recipes.',
    price: 49.99,
    images: [
      'https://images.pexels.com/photos/3747500/pexels-photo-3747500.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/4226896/pexels-photo-4226896.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
    ],
    category: 'Books',
    stock: 12,
    rating: 4.6,
    reviews: 42,
    tags: ['cookbook', 'recipes', 'culinary']
  }
];