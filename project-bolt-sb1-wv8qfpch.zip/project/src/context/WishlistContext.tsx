import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { WishlistState, Product } from '../types';

// Define actions
type WishlistAction =
  | { type: 'ADD_TO_WISHLIST'; payload: Product }
  | { type: 'REMOVE_FROM_WISHLIST'; payload: string }
  | { type: 'CLEAR_WISHLIST' }
  | { type: 'SET_WISHLIST'; payload: Product[] };

// Initial state
const initialState: WishlistState = {
  items: [],
  loading: false,
  error: null,
};

// Create context
const WishlistContext = createContext<{
  state: WishlistState;
  addToWishlist: (product: Product) => void;
  removeFromWishlist: (productId: string) => void;
  clearWishlist: () => void;
  isInWishlist: (productId: string) => boolean;
}>({
  state: initialState,
  addToWishlist: () => {},
  removeFromWishlist: () => {},
  clearWishlist: () => {},
  isInWishlist: () => false,
});

// Reducer function
const wishlistReducer = (state: WishlistState, action: WishlistAction): WishlistState => {
  switch (action.type) {
    case 'ADD_TO_WISHLIST': {
      // Check if item is already in wishlist
      const exists = state.items.some(item => item.id === action.payload.id);
      
      if (exists) {
        return state;
      }
      
      return {
        ...state,
        items: [...state.items, action.payload],
      };
    }
    
    case 'REMOVE_FROM_WISHLIST': {
      return {
        ...state,
        items: state.items.filter(item => item.id !== action.payload),
      };
    }
    
    case 'CLEAR_WISHLIST':
      return {
        ...state,
        items: [],
      };

    case 'SET_WISHLIST':
      return {
        ...state,
        items: action.payload,
      };
      
    default:
      return state;
  }
};

// Provider component
export const WishlistProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(wishlistReducer, initialState);

  // Load wishlist from localStorage on initial render
  useEffect(() => {
    const storedWishlist = localStorage.getItem('wishlist');
    if (storedWishlist) {
      try {
        const parsedWishlist = JSON.parse(storedWishlist);
        dispatch({ type: 'SET_WISHLIST', payload: parsedWishlist });
      } catch (error) {
        console.error('Failed to parse wishlist from localStorage:', error);
        localStorage.removeItem('wishlist');
      }
    }
  }, []);

  // Save wishlist to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('wishlist', JSON.stringify(state.items));
  }, [state.items]);

  // Add product to wishlist
  const addToWishlist = (product: Product): void => {
    dispatch({ type: 'ADD_TO_WISHLIST', payload: product });
  };

  // Remove product from wishlist
  const removeFromWishlist = (productId: string): void => {
    dispatch({ type: 'REMOVE_FROM_WISHLIST', payload: productId });
  };

  // Clear wishlist
  const clearWishlist = (): void => {
    dispatch({ type: 'CLEAR_WISHLIST' });
  };

  // Check if product is in wishlist
  const isInWishlist = (productId: string): boolean => {
    return state.items.some(item => item.id === productId);
  };

  return (
    <WishlistContext.Provider value={{ state, addToWishlist, removeFromWishlist, clearWishlist, isInWishlist }}>
      {children}
    </WishlistContext.Provider>
  );
};

// Custom hook to use the wishlist context
export const useWishlist = () => useContext(WishlistContext);